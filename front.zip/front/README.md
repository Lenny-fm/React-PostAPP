# Front

# Setup Project

## Install

```bash
npm install
```

## Run

```bash
npm start
```

## Build

```bash
npm run build
```