# Back

# Setup Project

## Install

```bash
npm install
```

## Run

```bash
npx nodemon index.js
```